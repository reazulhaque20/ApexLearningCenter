app.controller('indexCtrl', function (serverURL, uiURL, $scope, $http, $window, SweetAlert) {
    
    
});